# Rendu pour le TP1 + TP2 Dynamique des Connaissances

## Membres:
- NGUYEN Viet Anh
- BOURNIER Jocelyn

## Des fichiers importants:
- Contexte JSON-LD : Fichier "ctx.json"
- Trace brute: Fichier "scrapped.json"
- Fichier RDF généré "rdf_file.ttl"

## Fichier README:
- Lien de Github:
https://github.com/pchampin/sophia_rs

- Nous avons eu des soucis avec GraphDB pour l'import, (erreur de HeapMemory) mais la validation SHACL en local (avec script) marche et valide complètement le fichier généré.